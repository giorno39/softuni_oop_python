v = "     "
v = v.replace(" ", "")
print(f"-{v}-")